package com.example.javaeats;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HelloController {
    public Stage stage2 = new Stage();
    public ToggleGroup tg = new ToggleGroup();
    public RadioButton cash;
    public RadioButton visa;
    public static double totalAmount = 0;
    public static String promoCode = "OOP50";
    public Label totalBill = new Label();

    public TextField promofield;
    public Label error;
    public static AnchorPane root2 = new AnchorPane();
    public static Scene scene2 = new Scene(root2);
    public TextField name;
    public Button cartButton;
    private FoodItem foodItem = FoodItem.values()[0];
    private String pw;
    private Stage stage;
    private Scene scene;
    private Parent root;
    public TextField loginUsername;
    public TextField loginPassword;
    public Label message;
    public Label total;
    public TextField email;
    public TextField signupPassword;
    public TextField confirmPassword;
    public Button logout;
    private static final String regex = "^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$";
    public Pattern pattern = Pattern.compile(regex);
    public Matcher matcher;
    private String userData;
    private String[] userDataList;

    static HashMap<String,String[]> map = new HashMap<>();
//    static Map<>
    File fname = new File("C:\\Users\\123\\Desktop\\JavaEats\\src\\main\\java\\com\\example\\javaeats\\users.txt");
    Path path = Paths.get(fname.toURI());
    FileWriter fwriter = new FileWriter(fname,true);
    public static TableView<MenuData> table = new TableView<>();
    private static final ObservableList<MenuData> data = FXCollections.observableArrayList();




    public HelloController() throws IOException {

    }



    public void cart(ActionEvent event) throws IOException {

        Label label1 = new Label(" ");
        label1.setLayoutX(300);
        label1.setLayoutY(425);
        label1.setFont(Font.font("Verdana", FontWeight.BOLD, FontPosture.REGULAR, 13));
        label1.setTextFill(Color.RED);
        label1.setStyle("-fx-background-color: white");
        root2.getChildren().add(label1);

        if(root2.getChildren().contains(table)){

            label1.setText(String.valueOf(totalAmount));
//            label1.setLayoutX(300);
//            label1.setLayoutY(425);
//            label1.setFont(Font.font("Verdana", FontWeight.BOLD, FontPosture.REGULAR, 13));
//            label1.setTextFill(Color.RED);
//            root2.getChildren().add(label1);

        }else{
            TableColumn firstNameCol = new TableColumn("Item Names");
            firstNameCol.setMinWidth(200);
            firstNameCol.setCellValueFactory(
                    new PropertyValueFactory<MenuData, String>("itemName"));

            TableColumn lastNameCol = new TableColumn("Quantity");
            lastNameCol.setMinWidth(20);
            lastNameCol.setCellValueFactory(
                    new PropertyValueFactory<MenuData, String>("Quantity"));

            TableColumn emailCol = new TableColumn("Price");
            emailCol.setMinWidth(100);
            emailCol.setCellValueFactory(
                    new PropertyValueFactory<MenuData, String>("Price"));

            TableColumn close = new TableColumn("close");
            close.setMinWidth(50);


            table.getColumns().addAll(firstNameCol, lastNameCol, emailCol);
            table.setItems(data);
            root2.getChildren().add(table);

          //Label for total text
            Label label = new Label("Total: ");
            label.setLayoutX(250);
            label.setLayoutY(425);
            label.setFont(Font.font("Verdana", FontWeight.BOLD, FontPosture.REGULAR, 14));
            root2.getChildren().add(label);

        //    String bill = String.valueOf(totalAmount);
        //    Label for the total price
        //    Label label1 = new Label(" ");
        //    label1.setText(bill);
            label1.setText(String.valueOf(totalAmount));
//            label1.setLayoutX(300);
//            label1.setLayoutY(425);
//            label1.setFont(Font.font("Verdana", FontWeight.BOLD, FontPosture.REGULAR, 13));
//            label1.setTextFill(Color.RED);
//            root2.getChildren().add(label1);

            //Checkout Button
            Button checkout = new Button("Proceed To Pay");
            checkout.setLayoutX(280);
            checkout.setLayoutY(450);
            checkout.setStyle("-fx-background-color: Red");
            checkout.setFont(Font.font("Comic Sans MS",12));
            checkout.setTextFill(Color.WHITE);
            root2.getChildren().add(checkout);

            //change cursor to hand when hover above it
            checkout.setCursor(Cursor.HAND);

            checkout.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    stage2.hide();
                    try {
                       // totalBill.setText(String.valueOf(totalAmount));
                        checkoutButton(event);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            });

            //Empty label, don't touch it
            Label label2 =new Label(" ");
            label2.setLayoutX(10);
            label2.setLayoutY(470);
            root2.getChildren().add(label2);

        }

        stage2.setScene(scene2);
        stage2.show();
       // stage.hide();
    }
    public void pricing(){

        totalBill.setText(String.valueOf(totalAmount));

    }

//    public void checkLogin(ActionEvent event) throws IOException {
//        userData = Files.readAllLines(path).toString();
//        userData = userData.replaceAll("\\[","");
//        userData = userData.replaceAll("]","");
//        if(userData.isEmpty()){
//        }else{
//            userData = userData.replaceAll(", ","");
//            userDataList = userData.split("/");
//            for (int i =0; i < userDataList.length;i+=3) {
//                map.put(userDataList[i], new String[]{userDataList[i + 1], userDataList[i + 2]});
//            }
//        }
//        if((map.containsKey(loginUsername.getText())) && (loginPassword.getText().equals(map.get(loginUsername.getText())[0]))){
//            root = FXMLLoader.load(getClass().getResource("hello-view.fxml"));
//            stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
//            scene = new Scene(root);
//            stage.setScene(scene);
//            stage.show();
//        }
//        else if(loginUsername.getText().isEmpty() || loginPassword.getText().isEmpty()){
//            message.setText("Please fill in required fields");
//        }
//        else{
//            message.setText("Incorrect Username or Password!");
//            loginPassword.clear();
//        }
//    }

    public void checkLogin(ActionEvent event) throws IOException, SQLException {
//        userData = Files.readAllLines(path).toString();
//        userData = userData.replaceAll("\\[","");
//        userData = userData.replaceAll("]","");
//        if(userData.isEmpty()){
//        }else{
//            userData = userData.replaceAll(", ","");
//            userDataList = userData.split("/");
//            for (int i =0; i < userDataList.length;i+=3) {
//                map.put(userDataList[i], new String[]{userDataList[i + 1], userDataList[i + 2]});
//            }
//        }
        String email = null, pass = null;
        if(readData(loginUsername.getText()) != null){
            email = readData(loginUsername.getText())[0];
            pass = readData(loginUsername.getText())[1];
        }
        if(loginUsername.getText().equals(email) && loginPassword.getText().equals(pass)){
            root = FXMLLoader.load(getClass().getResource("hello-view.fxml"));
            stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }
        else if(loginUsername.getText().isEmpty() || loginPassword.getText().isEmpty()){
            message.setText("Please fill in required fields");
        }
        else{
            message.setText("Incorrect Username or Password!");
            loginPassword.clear();
        }
    }



//    public void signUp(ActionEvent event) throws IOException {
//        userData = Files.readAllLines(path).toString();
//        userData = userData.replaceAll("\\[","");
//        userData = userData.replaceAll("]","");
//        if(userData.isEmpty()){
//        }else{
//            userData = userData.replaceAll(", ","");
//            userDataList = userData.split("/");
//            for (int i =0; i < userDataList.length;i+=3) {
//                map.put(userDataList[i], new String[]{userDataList[i + 1], userDataList[i + 2]});
//            }
//        }
//        matcher = pattern.matcher(email.getText());
//
//        if(email.getText().isEmpty() || signupPassword.getText().isEmpty() || name.getText().isEmpty() || confirmPassword.getText().isEmpty()){
//            message.setText("Please fill in required fields");
//        }
//        else if (map.containsKey(email.getText())) {
//            message.setText("User already exists! try another email address");
//        }
//        else if(!(matcher.matches())){
//            message.setText("Invalid Email address");
//        }
////        else if(!(email.getText().endsWith("@gmail.com"))){
////            message.setText("Invalid Email Address");
////        }
//        else if(signupPassword.getText().length() < 8){
//            message.setText("Password cannot be less than 8 characters");
//        }
//        else if (((!Objects.equals(signupPassword.getText(), confirmPassword.getText())))) {
//            message.setText("Password and confirm Password are not same");
//        }
//        else{
//            map.put(email.getText(),new String[]{signupPassword.getText(), name.getText()});
//            root = FXMLLoader.load(getClass().getResource("Login.fxml"));
//            stage = (Stage)((Node)event.getSource()).getScene().getWindow();
//            scene = new Scene(root);
//            stage.setScene(scene);
//            stage.show();
//            fwriter.write(email.getText()+"/");
//            fwriter.write(signupPassword.getText()+"/");
//            fwriter.write(name.getText()+"/");
//            fwriter.write("\n");
//            fwriter.close();
//        }
//    }

    public void signUp(ActionEvent event) throws IOException, SQLException {
//        userData = Files.readAllLines(path).toString();
//        userData = userData.replaceAll("\\[","");
//        userData = userData.replaceAll("]","");
//        if(userData.isEmpty()){
//        }else{
//            userData = userData.replaceAll(", ","");
//            userDataList = userData.split("/");
//            for (int i =0; i < userDataList.length;i+=3) {
//                map.put(userDataList[i], new String[]{userDataList[i + 1], userDataList[i + 2]});
//            }
//        }
        String mail = null;
        if(readData(email.getText()) != null){
            mail = readData(email.getText())[0];
        }

        matcher = pattern.matcher(email.getText());

        if(email.getText().isEmpty() || signupPassword.getText().isEmpty() || name.getText().isEmpty() || confirmPassword.getText().isEmpty()){
            message.setText("Please fill in required fields");
        }
        else if (email.getText().equals(mail)) {
            message.setText("User already exists! try another email address");
        }
        else if(!(matcher.matches())){
            message.setText("Invalid Email address");
        }
        else if(signupPassword.getText().length() < 8){
            message.setText("Password cannot be less than 8 characters");
        }
        else if (((!Objects.equals(signupPassword.getText(), confirmPassword.getText())))) {
            message.setText("Password and confirm Password are not same");
        }
        else{

//            map.put(email.getText(),new String[]{signupPassword.getText(), name.getText()});
            root = FXMLLoader.load(getClass().getResource("Login.fxml"));
            stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
            insertData(email.getText(), signupPassword.getText(), name.getText());
        }
    }

    public void insertData(String email, String password, String name) throws SQLException {
        Connection connection = DBConnection.connect();
        PreparedStatement ps = null;
        String sql = "INSERT INTO Users(email, password, name) VALUES(?, ?, ?)";
        ps = connection.prepareStatement(sql);
        ps.setString(1, email);
        ps.setString(2, password);
        ps.setString(3, name);
        ps.execute();
    }

    public String[] readData(String email) throws SQLException {
        Connection connection = DBConnection.connect();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String[] data = null;

        String sql = "Select password, email from Users where email = ?";
        try{
            ps = connection.prepareStatement(sql);
            ps.setString(1, email);
            rs = ps.executeQuery();
            String password = rs.getString("Password");
            String Email = rs.getString("Email");
            data = new String[]{Email, password};

        }catch(SQLException ignored){

        }
        finally {
            rs.close();
            ps.close();
            connection.close();
        }

        return data;
    }

    public void chickenBurger(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.CHICKENBURGER.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.CHICKENBURGER.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.CHICKENBURGER.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.CHICKENBURGER.name, foodItem.quantity, foodItem.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.CHICKENBURGER.name, foodItem.quantity, foodItem.getPrice()));
        }

        totalAmount = totalAmount + FoodItem.CHICKENBURGER.price;

    }
    public void zingerBurger(ActionEvent event){
            boolean match = false;
            for (int i = 0; i < table.getItems().size(); i++) {
                Object cellValue = table.getColumns().get(0).getCellData(i);
                if (cellValue.equals(FoodItem.ZINGERBURGER.name)) {
                    match = true;
                    break;
                }
            }
            if(match){
                FoodItem.ZINGERBURGER.increaseQuantity();
                int index;
                for(index = 0; index < data.size();index++){
                    if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.ZINGERBURGER.name)){
                        data.remove(index);
                        data.add(index, new MenuData(FoodItem.ZINGERBURGER.name, FoodItem.ZINGERBURGER.quantity, FoodItem.ZINGERBURGER.getPrice()));
                        break;
                    }
                }
            }if(match == false){
                data.add(new MenuData(FoodItem.ZINGERBURGER.name, FoodItem.ZINGERBURGER.quantity, FoodItem.ZINGERBURGER.getPrice()));
            }

        totalAmount = totalAmount + FoodItem.ZINGERBURGER.price;

    }
    public void beefBurger(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.BEEFBURGER.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.BEEFBURGER.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.BEEFBURGER.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.BEEFBURGER.name, FoodItem.BEEFBURGER.quantity, FoodItem.BEEFBURGER.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.BEEFBURGER.name, FoodItem.BEEFBURGER.quantity, FoodItem.BEEFBURGER.getPrice()));
        }

        totalAmount = totalAmount + FoodItem.BEEFBURGER.price;

    }
    public void doubleBeefBurger(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.DOUBLEBEEFBURGER.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.DOUBLEBEEFBURGER.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.DOUBLEBEEFBURGER.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.DOUBLEBEEFBURGER.name, FoodItem.DOUBLEBEEFBURGER.quantity, FoodItem.DOUBLEBEEFBURGER.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.DOUBLEBEEFBURGER.name, FoodItem.DOUBLEBEEFBURGER.quantity, FoodItem.DOUBLEBEEFBURGER.getPrice()));
        }
        totalAmount = totalAmount + FoodItem.DOUBLEBEEFBURGER.price;

    }
    public void andaShami(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.ANDASHAMI.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.ANDASHAMI.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.ANDASHAMI.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.ANDASHAMI.name, FoodItem.ANDASHAMI.quantity, FoodItem.ANDASHAMI.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.ANDASHAMI.name, FoodItem.ANDASHAMI.quantity, FoodItem.ANDASHAMI.getPrice()));
        }
        totalAmount = totalAmount + FoodItem.ANDASHAMI.price;

    }
    public void zingerTower(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.ZINGERTOWER.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.ZINGERTOWER.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.ZINGERTOWER.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.ZINGERTOWER.name, FoodItem.ZINGERTOWER.quantity, FoodItem.ZINGERTOWER.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.ZINGERTOWER.name, FoodItem.ZINGERTOWER.quantity, FoodItem.ZINGERTOWER.getPrice()));
        }
        totalAmount = totalAmount + FoodItem.ZINGERTOWER.price;

    }
    public void chickenShwarma(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.CHICKENSHWARMA.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.CHICKENSHWARMA.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.CHICKENSHWARMA.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.CHICKENSHWARMA.name, FoodItem.CHICKENSHWARMA.quantity, FoodItem.CHICKENSHWARMA.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.CHICKENSHWARMA.name, FoodItem.CHICKENSHWARMA.quantity, FoodItem.CHICKENSHWARMA.getPrice()));
        }
        totalAmount = totalAmount + FoodItem.CHICKENSHWARMA.price;

    }
    public void zingeratha(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.ZINGERATHA.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.ZINGERATHA.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.ZINGERATHA.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.ZINGERATHA.name, FoodItem.ZINGERATHA.quantity, FoodItem.ZINGERATHA.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.ZINGERATHA.name, FoodItem.ZINGERATHA.quantity, FoodItem.ZINGERATHA.getPrice()));
        }
        totalAmount = totalAmount + FoodItem.ZINGERATHA.price;

    }
    public void bbqShwarma(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.BBQSHWARMA.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.BBQSHWARMA.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.BBQSHWARMA.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.BBQSHWARMA.name, FoodItem.BBQSHWARMA.quantity, FoodItem.BBQSHWARMA.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.BBQSHWARMA.name, FoodItem.BBQSHWARMA.quantity, FoodItem.BBQSHWARMA.getPrice()));
        }
        totalAmount = totalAmount + FoodItem.BBQSHWARMA.price;

    }
    public void shwarmaPlatter(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.SHWARMAPLATTER.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.SHWARMAPLATTER.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.SHWARMAPLATTER.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.SHWARMAPLATTER.name, FoodItem.SHWARMAPLATTER.quantity, FoodItem.SHWARMAPLATTER.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.SHWARMAPLATTER.name, FoodItem.SHWARMAPLATTER.quantity, FoodItem.SHWARMAPLATTER.getPrice()));
        }
        totalAmount = totalAmount + FoodItem.SHWARMAPLATTER.price;

    }
    public void cheesyShwarma(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.CHEESYSHWARMA.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.CHEESYSHWARMA.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.CHEESYSHWARMA.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.CHEESYSHWARMA.name, FoodItem.CHEESYSHWARMA.quantity, FoodItem.CHEESYSHWARMA.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.CHEESYSHWARMA.name, FoodItem.CHEESYSHWARMA.quantity, FoodItem.CHEESYSHWARMA.getPrice()));
        }
        totalAmount = totalAmount + FoodItem.CHEESYSHWARMA.price;

    }
    public void bonelessHandi(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.BONELESSHANDI.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.BONELESSHANDI.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.BONELESSHANDI.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.BONELESSHANDI.name, FoodItem.BONELESSHANDI.quantity, FoodItem.BONELESSHANDI.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.BONELESSHANDI.name, FoodItem.BONELESSHANDI.quantity, FoodItem.BONELESSHANDI.getPrice()));
        }
        totalAmount = totalAmount + FoodItem.BONELESSHANDI.price;

    }
    public void chickenKarahi(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.CHICKENKARAHI.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.CHICKENKARAHI.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.CHICKENKARAHI.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.CHICKENKARAHI.name, FoodItem.CHICKENKARAHI.quantity, FoodItem.CHICKENKARAHI.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.CHICKENKARAHI.name, FoodItem.CHICKENKARAHI.quantity, FoodItem.CHICKENKARAHI.getPrice()));
        }
        totalAmount = totalAmount + FoodItem.CHICKENKARAHI.price;

    }
    public void seekhKabab(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.SEEKHKABAB.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.SEEKHKABAB.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.SEEKHKABAB.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.SEEKHKABAB.name, FoodItem.SEEKHKABAB.quantity, FoodItem.SEEKHKABAB.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.SEEKHKABAB.name, FoodItem.SEEKHKABAB.quantity, FoodItem.SEEKHKABAB.getPrice()));
        }
        totalAmount = totalAmount + FoodItem.SEEKHKABAB.price;

    }
    public void malaiBoti(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.MALAIBOTI.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.MALAIBOTI.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.MALAIBOTI.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.MALAIBOTI.name, FoodItem.MALAIBOTI.quantity, FoodItem.MALAIBOTI.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.MALAIBOTI.name, FoodItem.MALAIBOTI.quantity, FoodItem.MALAIBOTI.getPrice()));
        }
        totalAmount = totalAmount + FoodItem.MALAIBOTI.price;

    }
    public void naan(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.NAAN.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.NAAN.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.NAAN.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.NAAN.name, FoodItem.NAAN.quantity, FoodItem.NAAN.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.NAAN.name, FoodItem.NAAN.quantity, FoodItem.NAAN.getPrice()));
        }
        totalAmount = totalAmount + FoodItem.NAAN.price;

    }
    public void roti(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.ROTI.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.ROTI.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.ROTI.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.ROTI.name, FoodItem.ROTI.quantity, FoodItem.ROTI.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.ROTI.name, FoodItem.ROTI.quantity, FoodItem.ROTI.getPrice()));
        }
        totalAmount = totalAmount + FoodItem.ROTI.price;

    }
    public void masalaFries(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.MASALAFRIES.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.MASALAFRIES.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.MASALAFRIES.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.MASALAFRIES.name, FoodItem.MASALAFRIES.quantity, FoodItem.MASALAFRIES.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.MASALAFRIES.name, FoodItem.MASALAFRIES.quantity, FoodItem.MASALAFRIES.getPrice()));
        }
        totalAmount = totalAmount + FoodItem.MASALAFRIES.price;

    }

    public void loadedFries(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.LOADEDFRIES.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.LOADEDFRIES.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.LOADEDFRIES.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.LOADEDFRIES.name, FoodItem.LOADEDFRIES.quantity, FoodItem.LOADEDFRIES.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.LOADEDFRIES.name, FoodItem.LOADEDFRIES.quantity, FoodItem.LOADEDFRIES.getPrice()));
        }
        totalAmount = totalAmount + FoodItem.LOADEDFRIES.price;

    }
    public void extraCheese(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.EXTRACHEESE.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.EXTRACHEESE.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.EXTRACHEESE.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.EXTRACHEESE.name, FoodItem.EXTRACHEESE.quantity, FoodItem.EXTRACHEESE.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.EXTRACHEESE.name, FoodItem.EXTRACHEESE.quantity, FoodItem.EXTRACHEESE.getPrice()));
        }
        totalAmount = totalAmount + FoodItem.EXTRACHEESE.price;

    }
    public void mayoColeslaw(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.MAYOCOLESLAW.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.MAYOCOLESLAW.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.MAYOCOLESLAW.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.MAYOCOLESLAW.name, FoodItem.MAYOCOLESLAW.quantity, FoodItem.MAYOCOLESLAW.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.MAYOCOLESLAW.name, FoodItem.MAYOCOLESLAW.quantity, FoodItem.MAYOCOLESLAW.getPrice()));
        }
        totalAmount = totalAmount + FoodItem.MAYOCOLESLAW.price;

    }
    public void garlicMayoDip(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.GARLICMAYODIP.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.GARLICMAYODIP.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.GARLICMAYODIP.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.GARLICMAYODIP.name, FoodItem.GARLICMAYODIP.quantity, FoodItem.GARLICMAYODIP.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.GARLICMAYODIP.name, FoodItem.GARLICMAYODIP.quantity, FoodItem.GARLICMAYODIP.getPrice()));
        }
        totalAmount = totalAmount + FoodItem.GARLICMAYODIP.price;

    }
    public void cocaCola(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.COCACOLA.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.COCACOLA.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.COCACOLA.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.COCACOLA.name, FoodItem.COCACOLA.quantity, FoodItem.COCACOLA.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.COCACOLA.name, FoodItem.COCACOLA.quantity, FoodItem.COCACOLA.getPrice()));
        }
        totalAmount = totalAmount + FoodItem.COCACOLA.price;

    }
    public void sprite(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.SPRITE.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.SPRITE.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.SPRITE.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.SPRITE.name, FoodItem.SPRITE.quantity, FoodItem.SPRITE.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.SPRITE.name, FoodItem.SPRITE.quantity, FoodItem.SPRITE.getPrice()));
        }
        totalAmount = totalAmount + FoodItem.SPRITE.price;

    }
    public void mirinda(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.MIRINDA.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.MIRINDA.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.MIRINDA.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.MIRINDA.name, FoodItem.MIRINDA.quantity, FoodItem.MIRINDA.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.MIRINDA.name, FoodItem.MIRINDA.quantity, FoodItem.MIRINDA.getPrice()));
        }
        totalAmount = totalAmount + FoodItem.MIRINDA.price;

    }
    public void mintMargarita(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.MINTMARGARITA.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.MINTMARGARITA.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.MINTMARGARITA.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.MINTMARGARITA.name, FoodItem.MINTMARGARITA.quantity, FoodItem.MINTMARGARITA.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.MINTMARGARITA.name, FoodItem.MINTMARGARITA.quantity, FoodItem.MINTMARGARITA.getPrice()));
        }
        totalAmount = totalAmount + FoodItem.MINTMARGARITA.price;

    }
    public void chai(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.CHAI.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.CHAI.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.CHAI.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.CHAI.name, FoodItem.CHAI.quantity, FoodItem.CHAI.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.CHAI.name, FoodItem.CHAI.quantity, FoodItem.CHAI.getPrice()));
        }
        totalAmount = totalAmount + FoodItem.CHAI.price;

    }
    public void beefCombo(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.BEEFCOMBO.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.BEEFCOMBO.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.BEEFCOMBO.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.BEEFCOMBO.name, FoodItem.BEEFCOMBO.quantity, FoodItem.BEEFCOMBO.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.BEEFCOMBO.name, FoodItem.BEEFCOMBO.quantity, FoodItem.BEEFCOMBO.getPrice()));
        }
        totalAmount = totalAmount + FoodItem.BEEFCOMBO.price;

    }
    public void pattyCombo(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.PATTYCOMBO.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.PATTYCOMBO.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.PATTYCOMBO.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.PATTYCOMBO.name, FoodItem.PATTYCOMBO.quantity, FoodItem.PATTYCOMBO.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.PATTYCOMBO.name, FoodItem.PATTYCOMBO.quantity, FoodItem.PATTYCOMBO.getPrice()));
        }
        totalAmount = totalAmount + FoodItem.PATTYCOMBO.price;

    }
    public void mightyCombo(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.MIGHTYCOMBO.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.MIGHTYCOMBO.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.MIGHTYCOMBO.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.MIGHTYCOMBO.name, FoodItem.MIGHTYCOMBO.quantity, FoodItem.MIGHTYCOMBO.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.MIGHTYCOMBO.name, FoodItem.MIGHTYCOMBO.quantity, FoodItem.MIGHTYCOMBO.getPrice()));
        }
        totalAmount = totalAmount + FoodItem.MIGHTYCOMBO.price;

    }
    public void shwarmaCombo(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.SHWARMACOMBO.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.SHWARMACOMBO.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.SHWARMACOMBO.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.SHWARMACOMBO.name, FoodItem.SHWARMACOMBO.quantity, FoodItem.SHWARMACOMBO.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.SHWARMACOMBO.name, FoodItem.SHWARMACOMBO.quantity, FoodItem.SHWARMACOMBO.getPrice()));
        }
        totalAmount = totalAmount + FoodItem.SHWARMACOMBO.price;

    }
    public void bbqPlatter(ActionEvent event){
        boolean match = false;
        for (int i = 0; i < table.getItems().size(); i++) {
            Object cellValue = table.getColumns().get(0).getCellData(i);
            if (cellValue.equals(FoodItem.BBQPLATTER.name)) {
                match = true;
                break;
            }
        }
        if(match){
            FoodItem.BBQPLATTER.increaseQuantity();
            int index;
            for(index = 0; index < data.size();index++){
                if(data.get(index).itemName.get().equalsIgnoreCase(FoodItem.BBQPLATTER.name)){
                    data.remove(index);
                    data.add(index, new MenuData(FoodItem.BBQPLATTER.name, FoodItem.BBQPLATTER.quantity, FoodItem.BBQPLATTER.getPrice()));
                    break;
                }
            }
        }if(match == false){
            data.add(new MenuData(FoodItem.BBQPLATTER.name, FoodItem.BBQPLATTER.quantity, FoodItem.BBQPLATTER.getPrice()));
        }
        totalAmount = totalAmount + FoodItem.BBQPLATTER.price;

    }
    public void makeLabelDisappear(MouseEvent event){
        message.setText("");
    }

    public void changeScene(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Signup.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void logOut(ActionEvent event) throws IOException {
        data.clear();
        root = FXMLLoader.load(getClass().getResource("Login.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToScene1(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Homepage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void burgerButton(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Scene2.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }

    public void wrapsButton(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Scene3.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }

    public void extrasButton(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Scene5.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void desiButton(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Scene4.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void drinksButton(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Scene6.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void checkoutButton(ActionEvent event) throws IOException {

        root = FXMLLoader.load(getClass().getResource("Payment.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }

    public void thanksButton(ActionEvent event) throws IOException {

        if(cash.isSelected() || visa.isSelected()) {
            totalAmount = 00.0000;
            java.awt.Toolkit.getDefaultToolkit().beep();
            try {
                Thread.sleep(1000); // introduce delay
            } catch (InterruptedException e) {
            }

            root = FXMLLoader.load(getClass().getResource("Thanks.fxml"));
            stage2 = (Stage) ((Node) event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage2.setScene(scene);
            stage2.show();
        }
        else{
            error.setText("Kindly select a Payment Method");
        }

    }

    public void applyButton(ActionEvent event) throws IOException {

        if(promofield.getText().equalsIgnoreCase(promoCode)) {
            totalAmount = totalAmount / 2;
            totalBill.setText(String.valueOf(totalAmount));
            error.setText("Promo Code Successfully Applied!!");
            promofield.clear();
          }
        else{
            error.setText("Incorrect Promo Code");
            promofield.clear();

        }

    }
    public void okButton(ActionEvent event) throws IOException {
        if(cash.isSelected() || visa.isSelected()) {
            totalBill.setText(String.valueOf(totalAmount));
        }
        else {
            error.setText("Kindly select a Payment Method");

        }
    }
    public void back(ActionEvent event) throws IOException {
        totalAmount=00.0000;
        switchToScene1(event);
        stage.close();
        data.clear();
    }
    public void backToMenu(ActionEvent event){
        stage2.close();
    }

}